CREATE DATABASE IF NOT EXISTS sistem_pengaduan_aspirasi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sistem_pengaduan_aspirasi;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS tanggapan_aspirasi;
DROP TABLE IF EXISTS tanggapan_pengaduan;
DROP TABLE IF EXISTS aspirasi;
DROP TABLE IF EXISTS pengaduan;
DROP TABLE IF EXISTS kategori;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS siswa;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE siswa (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nisn VARCHAR(20) NOT NULL UNIQUE,
    nama VARCHAR(120) NOT NULL,
    kelas VARCHAR(50) NOT NULL,
    jurusan VARCHAR(100) DEFAULT NULL,
    status ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    siswa_id INT UNSIGNED NULL,
    nama VARCHAR(120) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(120) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','siswa') NOT NULL,
    status ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_users_siswa FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE kategori (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(80) NOT NULL UNIQUE,
    tipe ENUM('pengaduan','aspirasi','keduanya') NOT NULL DEFAULT 'keduanya',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE pengaduan (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    siswa_id INT UNSIGNED NULL,
    created_by_user_id INT UNSIGNED NULL,
    kategori_id INT UNSIGNED NOT NULL,
    judul VARCHAR(150) NOT NULL,
    isi TEXT NOT NULL,
    lokasi VARCHAR(180) DEFAULT NULL,
    tanggal_pengaduan DATE NOT NULL,
    foto_bukti VARCHAR(255) DEFAULT NULL,
    anonim TINYINT(1) NOT NULL DEFAULT 0,
    status ENUM('Baru','Diproses','Selesai','Ditolak') NOT NULL DEFAULT 'Baru',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_pengaduan_siswa FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_pengaduan_user FOREIGN KEY (created_by_user_id) REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_pengaduan_kategori FOREIGN KEY (kategori_id) REFERENCES kategori(id) ON DELETE RESTRICT ON UPDATE CASCADE,
    INDEX idx_pengaduan_status (status),
    INDEX idx_pengaduan_tanggal (tanggal_pengaduan)
) ENGINE=InnoDB;

CREATE TABLE tanggapan_pengaduan (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    pengaduan_id INT UNSIGNED NOT NULL,
    admin_id INT UNSIGNED NOT NULL,
    tanggapan TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_tanggapan_pengaduan FOREIGN KEY (pengaduan_id) REFERENCES pengaduan(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_tanggapan_pengaduan_admin FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE aspirasi (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    siswa_id INT UNSIGNED NULL,
    created_by_user_id INT UNSIGNED NULL,
    kategori_id INT UNSIGNED NOT NULL,
    judul VARCHAR(150) NOT NULL,
    isi TEXT NOT NULL,
    tanggal_aspirasi DATE NOT NULL,
    anonim TINYINT(1) NOT NULL DEFAULT 0,
    status ENUM('Baru','Diproses','Selesai','Ditolak') NOT NULL DEFAULT 'Baru',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_aspirasi_siswa FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_aspirasi_user FOREIGN KEY (created_by_user_id) REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_aspirasi_kategori FOREIGN KEY (kategori_id) REFERENCES kategori(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE tanggapan_aspirasi (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    aspirasi_id INT UNSIGNED NOT NULL,
    admin_id INT UNSIGNED NOT NULL,
    tanggapan TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_tanggapan_aspirasi FOREIGN KEY (aspirasi_id) REFERENCES aspirasi(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_tanggapan_aspirasi_admin FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT INTO siswa (id, nisn, nama, kelas, jurusan, status) VALUES
(1, '0098765432', 'Reza Pratama', 'XI RPL 1', 'Rekayasa Perangkat Lunak', 'aktif'),
(2, '0098765433', 'Nadia Putri', 'XI RPL 1', 'Rekayasa Perangkat Lunak', 'aktif'),
(3, '0098765434', 'Fajar Ramadhan', 'XI RPL 2', 'Rekayasa Perangkat Lunak', 'aktif');

INSERT INTO users (id, siswa_id, nama, username, email, password, role, status) VALUES
(1, NULL, 'Administrator Sekolah', 'admin', 'admin@sistem.local', '$2y$12$688lHLC1L8tJY9qmByQ3..NOQ2ECZT/Z0BMdEODsjgWx6iGg3M1HK', 'admin', 'aktif'),
(2, 1, 'Reza Pratama', 'siswa01', 'siswa01@sistem.local', '$2y$12$k3nUemkEF3e8d9fs4EmGgeeVvIepizelILbSxywgtHO7YcjEc.xpq', 'siswa', 'aktif'),
(3, 2, 'Nadia Putri', 'siswa02', 'siswa02@sistem.local', '$2y$12$k3nUemkEF3e8d9fs4EmGgeeVvIepizelILbSxywgtHO7YcjEc.xpq', 'siswa', 'aktif');

INSERT INTO kategori (id, nama, tipe) VALUES
(1, 'Fasilitas Sekolah', 'pengaduan'),
(2, 'Kebersihan', 'keduanya'),
(3, 'Keamanan', 'keduanya'),
(4, 'Pembelajaran', 'keduanya'),
(5, 'Guru', 'keduanya'),
(6, 'Siswa', 'keduanya'),
(7, 'Lingkungan', 'keduanya'),
(8, 'Saran Sekolah', 'aspirasi'),
(9, 'Lainnya', 'keduanya');

INSERT INTO pengaduan (siswa_id, created_by_user_id, kategori_id, judul, isi, lokasi, tanggal_pengaduan, foto_bukti, anonim, status) VALUES
(1, 2, 1, 'Lampu kelas mati', 'Lampu di bagian belakang kelas XI RPL 1 mati sehingga ruangan menjadi kurang terang.', 'XI RPL 1', CURDATE(), NULL, 0, 'Baru'),
(NULL, 3, 2, 'Toilet perlu dibersihkan', 'Mohon toilet dekat lapangan mendapat jadwal pembersihan lebih rutin.', 'Toilet dekat lapangan', CURDATE(), NULL, 1, 'Diproses');

INSERT INTO aspirasi (siswa_id, created_by_user_id, kategori_id, judul, isi, tanggal_aspirasi, anonim, status) VALUES
(1, 2, 8, 'Penambahan tempat sampah', 'Saya mengusulkan penambahan tempat sampah terpilah di area kantin dan lapangan.', CURDATE(), 0, 'Baru'),
(2, 3, 4, 'Forum belajar bersama', 'Semoga sekolah dapat menyediakan sesi belajar bersama menjelang ujian.', CURDATE(), 0, 'Selesai');

INSERT INTO tanggapan_pengaduan (pengaduan_id, admin_id, tanggapan) VALUES
(2, 1, 'Terima kasih atas laporannya. Petugas kebersihan sudah dijadwalkan untuk melakukan pengecekan.');

INSERT INTO tanggapan_aspirasi (aspirasi_id, admin_id, tanggapan) VALUES
(2, 1, 'Usulan diterima dan sudah disampaikan kepada bagian kurikulum.');
