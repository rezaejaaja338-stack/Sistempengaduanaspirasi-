    </section>
</main>

<footer class="site-footer">
    <div class="container">
        <span>© <?= date('Y') ?> SMK Strada Jakarta</span>
        <span>Portal Pengaduan &amp; Aspirasi Siswa</span>
    </div>
</footer>
<script src="../assets/js/script.js"></script>
</body>
</html>
