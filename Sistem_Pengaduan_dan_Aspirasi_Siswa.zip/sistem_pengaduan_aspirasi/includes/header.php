<?php
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/icons.php';
require_once __DIR__ . '/illustrations.php';

$pageTitle = $pageTitle ?? 'Portal Pengaduan';
$role = $_SESSION['role'] ?? '';
$namaUser = $_SESSION['name'] ?? 'Pengguna';
$halaman = basename($_SERVER['SCRIPT_NAME']);

// menu: file | label | ikon | halaman lain yg ikut aktif
if ($role == 'admin') {
    $menu = [
        ['dashboard.php', 'Dashboard', 'home', []],
        ['siswa.php', 'Siswa', 'users', []],
        ['pengaduan.php', 'Pengaduan', 'doc', ['detail_pengaduan.php']],
        ['aspirasi.php', 'Aspirasi', 'bulb', ['detail_aspirasi.php']],
        ['kategori.php', 'Kategori', 'tag', []],
        ['laporan.php', 'Laporan', 'chart', []]
    ];
} else {
    $menu = [
        ['dashboard.php', 'Dashboard', 'home', []],
        ['buat_pengaduan.php', 'Pengaduan', 'doc', []],
        ['buat_aspirasi.php', 'Aspirasi', 'bulb', []],
        ['riwayat_pengaduan.php', 'Riwayat', 'history', ['riwayat_aspirasi.php', 'detail_pengaduan.php', 'detail_aspirasi.php']]
    ];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> | SMK Strada Jakarta</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<header class="topbar">
    <div class="container topbar-inner">
        <a class="brand" href="dashboard.php">
            <img src="../assets/img/logo.jpg" alt="Logo SMK Strada Jakarta">
            <strong>SMK STRADA JAKARTA</strong>
        </a>

        <nav class="main-nav" id="mainNav" aria-label="Menu utama">
            <?php foreach ($menu as [$file, $label, $ico, $lainnya]): ?>
                <?php $active = $halaman == $file || in_array($halaman, $lainnya); ?>
                <a href="<?= $file ?>" class="nav-link<?= $active ? ' active' : '' ?>"<?= $active ? ' aria-current="page"' : '' ?>>
                    <?= icon($ico) ?><span><?= $label ?></span>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="topbar-actions">
            <details class="user-menu">
                <summary>
                    <span class="user-avatar"><?= icon('user', 22) ?></span>
                    <span class="user-role"><?= e(ucfirst($role)) ?></span>
                    <span class="chev"><?= icon('chevron', 18) ?></span>
                </summary>
                <div class="user-dropdown">
                    <div class="user-dropdown-name">
                        <strong><?= e($namaUser) ?></strong>
                        <small><?= $role == 'admin' ? 'Administrator' : 'Siswa SMK Strada Jakarta' ?></small>
                    </div>
                    <a href="profil.php"><?= icon('gear', 20) ?> Profil</a>
                    <a href="../auth/logout.php" class="logout-link"><?= icon('logout', 20) ?> Keluar</a>
                </div>
            </details>
            <button class="menu-toggle" id="menuToggle" type="button" aria-label="Buka menu" aria-controls="mainNav" aria-expanded="false"><?= icon('menu', 26) ?></button>
        </div>
    </div>
</header>

<main class="container page">
    <?php if ($message = flash('success')): ?>
        <div class="alert alert-success"><?= icon('check', 20) ?> <?= e($message) ?></div>
    <?php endif; ?>

    <?php if ($message = flash('error')): ?>
        <div class="alert alert-danger"><?= icon('alert', 20) ?> <?= e($message) ?></div>
    <?php endif; ?>

    <section class="content-area">
