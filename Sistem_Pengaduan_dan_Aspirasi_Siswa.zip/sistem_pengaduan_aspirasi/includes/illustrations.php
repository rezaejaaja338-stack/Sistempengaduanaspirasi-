<?php
// gambar svg buat hero & kartu cta
function illustration_megaphone() {
    return <<<'SVG'
<svg class="illus illus-megaphone" viewBox="0 0 520 340" role="img" aria-label="Ilustrasi pengeras suara" xmlns="http://www.w3.org/2000/svg">
  <g fill="none" stroke="#12161d" stroke-width="4" stroke-linecap="round" stroke-linejoin="round">
    <!-- gelembung lime -->
    <circle cx="418" cy="78" r="54" fill="#c9f56b"/>
    <path d="M372 112 360 140 392 124" fill="#c9f56b"/>
    <path d="M404 66l-12-14M424 58V40M444 70l14-10M440 92l16 4" stroke-width="3.5"/>
    <!-- gelembung putih -->
    <path d="M410 196h86a14 14 0 0 1 14 14v22a14 14 0 0 1-14 14h-58l-22 16v-16h-6a14 14 0 0 1-14-14v-22a14 14 0 0 1 14-14z" fill="#fff"/>
    <circle cx="437" cy="221" r="3" fill="#12161d"/><circle cx="454" cy="221" r="3" fill="#12161d"/><circle cx="471" cy="221" r="3" fill="#12161d"/>
    <!-- pesawat kertas -->
    <path d="M340 196l-62 36 38 6 6 28 18-26 36-8z" fill="#fff"/>
    <path d="M316 238l62-42" stroke-width="3"/>
    <!-- garis suara -->
    <path d="M318 40l16 22M360 20l6 24M300 82l26 8" stroke-width="3.5"/>
    <g transform="translate(205 190) rotate(-32)">
      <!-- tangan -->
      <path d="M-78 54c-18 34-8 74 18 96h58c10-30 2-62-8-92z" fill="#fff"/>
      <path d="M-44 96h40M-46 116h38M-44 136h32" stroke-width="3"/>
      <!-- pegangan -->
      <rect x="-70" y="22" width="30" height="46" rx="9" fill="#fff"/>
      <!-- badan -->
      <path d="M-98 -26 52 -74V74L-98 26z" fill="#fff"/>
      <path d="M-58 -39 -8 -55V55L-58 39z" fill="#c9f56b"/>
      <ellipse cx="52" cy="0" rx="22" ry="74" fill="#12161d"/>
      <ellipse cx="46" cy="0" rx="9" ry="34" fill="#c9f56b" stroke="none"/>
    </g>
  </g>
  <g fill="#12161d">
    <path d="M70 70q4-26 8-26t8 26q26 4 26 8t-26 8q-4 26-8 26t-8-26q-26-4-26-8t26-8z" transform="translate(34 60) scale(.9)"/>
    <path d="M70 70q4-26 8-26t8 26q26 4 26 8t-26 8q-4 26-8 26t-8-26q-26-4-26-8t26-8z" transform="translate(92 262) scale(.38)"/>
    <path d="M70 70q4-26 8-26t8 26q26 4 26 8t-26 8q-4 26-8 26t-8-26q-26-4-26-8t26-8z" transform="translate(268 18) scale(.28)"/>
  </g>
  <circle cx="190" cy="82" r="14" fill="#c9f56b" stroke="#12161d" stroke-width="3"/>
  <circle cx="38" cy="186" r="12" fill="none" stroke="#12161d" stroke-width="3"/>
  <circle cx="352" cy="298" r="10" fill="#c9f56b"/>
</svg>
SVG;
}

function illustration_notepad() {
    return <<<'SVG'
<svg class="illus illus-notepad" viewBox="0 0 210 230" role="img" aria-label="Ilustrasi catatan dan pensil" xmlns="http://www.w3.org/2000/svg">
  <g fill="none" stroke="#12161d" stroke-width="4" stroke-linecap="round" stroke-linejoin="round">
    <g transform="rotate(8 105 130)">
      <rect x="40" y="58" width="116" height="140" rx="10" fill="#fff"/>
      <path d="M62 88h72M62 110h72M62 132h48" stroke-width="3.5"/>
      <path d="M68 52v14M96 52v14M124 52v14" stroke-width="5"/>
    </g>
    <path d="M150 24l32 14-46 108-18-6z" fill="#c9f56b"/>
    <path d="M118 140l-6 22 22-10" fill="#fff"/>
    <path d="M30 206q12-18 24-4t24-4" stroke-width="3.5"/>
  </g>
  <path d="M26 74q4-22 8-22t8 22q22 4 22 8t-22 8q-4 22-8 22t-8-22q-22-4-22-8t22-8z" fill="#12161d" transform="translate(-8 -26) scale(.9)"/>
</svg>
SVG;
}
