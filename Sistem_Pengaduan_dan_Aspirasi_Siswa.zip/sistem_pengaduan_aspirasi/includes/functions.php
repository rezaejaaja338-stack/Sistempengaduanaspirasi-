<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

function e($teks) {
    return htmlspecialchars((string) $teks, ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header('Location: ' . $url);
    exit;
}

function is_logged_in() {
    return isset($_SESSION['user_id'], $_SESSION['role']);
}

// $role dipakai buat nentuin dikirim ke halaman login yg mana
function require_login($role = 'siswa') {
    if (!is_logged_in()) {
        redirect('../' . $role . '/login.php');
    }
}

// kalau role-nya ga cocok, lempar ke dashboard sendiri
function require_role($role) {
    require_login($role);
    if ($_SESSION['role'] !== $role) {
        if ($_SESSION['role'] == 'admin') {
            redirect('../admin/dashboard.php');
        }
        redirect('../siswa/dashboard.php');
    }
}

function old($key, $default = '') {
    return e($_POST[$key] ?? $default);
}

// isi $pesan = simpan, kosong = ambil terus hapus
function flash($key, $pesan = null) {
    if ($pesan !== null) {
        $_SESSION['_flash'][$key] = $pesan;
        return null;
    }
    $isi = $_SESSION['_flash'][$key] ?? null;
    unset($_SESSION['_flash'][$key]);
    return $isi;
}

function csrf_token() {
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

function verify_csrf() {
    $token = $_POST['_csrf'] ?? '';
    if (!hash_equals($_SESSION['_csrf'] ?? '', $token)) {
        http_response_code(419);
        exit('Token keamanan tidak valid. Silakan kembali dan coba lagi.');
    }
}

function status_class($status) {
    switch ($status) {
        case 'Baru': return 'badge badge-blue';
        case 'Diproses': return 'badge badge-orange';
        case 'Selesai': return 'badge badge-green';
        case 'Ditolak': return 'badge badge-red';
    }
    return 'badge';
}

function format_date($tgl) {
    return date('d M Y', strtotime($tgl));
}

function format_datetime($tgl) {
    return date('d M Y, H:i', strtotime($tgl));
}

// balikin nama file baru (null kalo ga ada upload)
function upload_foto($file) {
    $err = $file['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($err == UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($err !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Upload foto gagal.');
    }

    if ($file['size'] > 3 * 1024 * 1024) {
        throw new RuntimeException('Ukuran foto maksimal 3 MB.');
    }

    $boleh = ['image/jpeg' => 'jpg', 'image/png' => 'png'];
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);

    if (!isset($boleh[$mime]) || @getimagesize($file['tmp_name']) === false) {
        throw new RuntimeException('Format foto harus JPG, JPEG, atau PNG.');
    }

    $namaFile = bin2hex(random_bytes(16)) . '.' . $boleh[$mime];
    if (!move_uploaded_file($file['tmp_name'], __DIR__ . '/../uploads/pengaduan/' . $namaFile)) {
        throw new RuntimeException('Foto tidak dapat disimpan.');
    }
    return $namaFile;
}

function hapus_foto($namaFile) {
    if (!$namaFile) return;

    $path = __DIR__ . '/../uploads/pengaduan/' . basename($namaFile);
    if (is_file($path)) {
        unlink($path);
    }
}
