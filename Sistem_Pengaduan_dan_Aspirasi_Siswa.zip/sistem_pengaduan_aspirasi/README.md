# Sistem Pengaduan Aspirasi

Website pengaduan & aspirasi siswa SMK Strada Jakarta. Pakai PHP native + MySQL, tanpa framework.

## Login (dipisah)
- siswa: `http://localhost/sistem_pengaduan_aspirasi/siswa/login.php` -> `siswa01` / `siswa123`
- admin: `http://localhost/sistem_pengaduan_aspirasi/admin/login.php` -> `admin` / `admin123`

## Cara jalanin (XAMPP)
1. Taruh folder `sistem_pengaduan_aspirasi` di `C:\xampp\htdocs\`
2. Start Apache & MySQL
3. Buka phpMyAdmin, import `database/sistem_pengaduan_aspirasi.sql`
4. Buka `http://localhost/sistem_pengaduan_aspirasi/`

Kalau MySQL pakai password, ubah `$password` di `config/database.php`.

## Upload foto
Foto bukti masuk ke `uploads/pengaduan/`. Cuma JPG/PNG, maksimal 3 MB.

## Folder
- `auth/` logout
- `admin/` halaman admin + login admin
- `siswa/` halaman siswa + login siswa
- `config/` koneksi database
- `includes/` header, footer, fungsi bantu
- `assets/` css, js, logo
- `database/` file sql

Mau ganti logo? Timpa `assets/img/logo.jpg` dengan nama file yang sama.
