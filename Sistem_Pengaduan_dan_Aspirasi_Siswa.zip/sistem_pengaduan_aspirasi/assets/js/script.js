document.addEventListener('DOMContentLoaded', function () {
    // buka tutup menu di hp
    var tombolMenu = document.getElementById('menuToggle');
    var nav = document.getElementById('mainNav');
    if (tombolMenu && nav) {
        tombolMenu.addEventListener('click', function () {
            var terbuka = nav.classList.toggle('open');
            tombolMenu.setAttribute('aria-expanded', terbuka);
        });
    }

    // dropdown user ketutup kalau klik di luar
    document.addEventListener('click', function (e) {
        document.querySelectorAll('.user-menu[open]').forEach(function (m) {
            if (!m.contains(e.target)) m.removeAttribute('open');
        });
    });

    // tombol lihat/sembunyikan password
    document.querySelectorAll('.password-toggle').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var input = document.getElementById(btn.dataset.target);
            if (!input) return;
            if (input.type == 'password') {
                input.type = 'text';
                btn.textContent = 'Sembunyikan';
            } else {
                input.type = 'password';
                btn.textContent = 'Lihat';
            }
        });
    });

    // tampilkan nama file yg dipilih di kotak upload
    document.querySelectorAll('input[type="file"]').forEach(function (input) {
        input.addEventListener('change', function () {
            var box = input.closest('.upload-box');
            if (box && input.files[0]) {
                box.querySelector('strong').textContent = input.files[0].name;
            }
        });
    });

    // konfirmasi sebelum hapus
    document.querySelectorAll('form[data-confirm]').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            if (!confirm(form.dataset.confirm)) e.preventDefault();
        });
    });

    // tombol cetak laporan
    document.querySelectorAll('[data-print]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            window.print();
        });
    });

    // alert hilang sendiri setelah 5 detik
    setTimeout(function () {
        document.querySelectorAll('.alert').forEach(function (a) {
            a.classList.add('alert-hide');
        });
    }, 5000);
});
