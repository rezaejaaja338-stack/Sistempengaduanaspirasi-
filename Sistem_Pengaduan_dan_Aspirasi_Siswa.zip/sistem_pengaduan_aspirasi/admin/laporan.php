<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$pageTitle = 'Laporan';
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$status = $_GET['status'] ?? '';
$kategoriId = (int) ($_GET['kategori_id'] ?? 0);
$daftarKategori = $pdo->query('SELECT id, nama FROM kategori ORDER BY nama')->fetchAll();

$where = ['p.tanggal_pengaduan BETWEEN :from AND :to'];
$params = ['from' => $from, 'to' => $to];
if ($status != '') {
    $where[] = 'p.status = :status';
    $params['status'] = $status;
}
if ($kategoriId > 0) {
    $where[] = 'p.kategori_id = :kategori_id';
    $params['kategori_id'] = $kategoriId;
}

$query = 'SELECT p.*, c.nama kategori, CASE WHEN p.anonim = 1 THEN "Anonim" ELSE COALESCE(s.nama, u.nama, "-") END reporter
        FROM pengaduan p
        LEFT JOIN kategori c ON c.id = p.kategori_id
        LEFT JOIN siswa s ON s.id = p.siswa_id
        LEFT JOIN users u ON u.id = p.created_by_user_id
        WHERE ' . implode(' AND ', $where) . ' ORDER BY p.tanggal_pengaduan DESC, p.id DESC';
$st = $pdo->prepare($query);
$st->execute($params);
$hasil = $st->fetchAll();

# aspirasi di periode yg sama
$st = $pdo->prepare('SELECT COUNT(*) FROM aspirasi WHERE tanggal_aspirasi BETWEEN :from AND :to');
$st->execute(['from' => $from, 'to' => $to]);
$jmlAspirasi = (int) $st->fetchColumn();

include __DIR__ . '/../includes/header.php';
?>
<div class="page-intro split no-print">
    <div><span class="eyebrow">REPORTING</span><h2>Laporan Pengaduan</h2><p>Gunakan filter untuk membuat laporan periode tertentu.</p></div>
    <button class="btn btn-primary" data-print>Cetak Laporan</button>
</div>
<form class="filter-card no-print" method="get"><label>Dari
    <input type="date" name="from" value="<?= e($from) ?>">
    </label><label>Sampai
    <input type="date" name="to" value="<?= e($to) ?>">
    </label>
    <select name="status">
        <option value="">Semua status</option>
        <?php foreach(['Baru','Diproses','Selesai','Ditolak'] as $s): ?>
            <option <?= $status===$s?'selected':'' ?>><?= $s ?></option>
        <?php endforeach; ?>
    </select>
    <select name="kategori_id">
        <option value="0">Semua kategori</option>
        <?php foreach($daftarKategori as $k): ?>
            <option value="<?= (int)$k['id'] ?>" <?= $kategoriId===(int)$k['id']?'selected':'' ?>><?= e($k['nama']) ?></option>
        <?php endforeach; ?>
    </select>
    <button class="btn btn-primary">Terapkan</button>
</form>
<div class="report-sheet" id="printArea">
    <div class="report-head"><img src="../assets/img/logo.jpg" alt="Logo">
        <div><h1>Sistem Pengaduan Aspirasi</h1><p>Laporan Pengaduan Siswa</p><small>Periode <?= format_date($from) ?> s/d <?= format_date($to) ?></small></div>
    </div>
    <div class="report-summary">
        <div><small>Total pengaduan</small><strong><?= count($hasil) ?></strong></div>
        <div><small>Aspirasi periode</small><strong><?= $jmlAspirasi ?></strong></div>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Judul</th>
                    <th>Pelapor</th>
                    <th>Kategori</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($hasil as $i=>$h): ?>
                    <tr>
                        <td><?= $i+1 ?></td>
                        <td><?= e($h['judul']) ?></td>
                        <td><?= e($h['reporter']) ?></td>
                        <td><?= e($h['kategori']??'-') ?></td>
                        <td><?= format_date($h['tanggal_pengaduan']) ?></td>
                        <td><?= e($h['status']) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if(!$hasil): ?>
                    <tr>
                        <td colspan="6">Tidak ada data pada periode ini.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="report-sign">
        <div>Mengetahui,<br>Kepala Sekolah</div>
        <div>Admin Sistem<br><br>__________________</div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
