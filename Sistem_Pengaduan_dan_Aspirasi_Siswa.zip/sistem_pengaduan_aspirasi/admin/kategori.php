<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$pageTitle = 'Kategori';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action == 'add') {
        $nama = trim($_POST['nama'] ?? '');
        $tipe = $_POST['tipe'] ?? 'keduanya';

        if ($nama == '' || !in_array($tipe, ['pengaduan', 'aspirasi', 'keduanya'])) {
            $error = 'Nama dan tipe kategori wajib benar.';
        } else {
            try {
                $q = $pdo->prepare('INSERT INTO kategori (nama, tipe) VALUES (:nama, :tipe)');
                $q->execute(['nama' => $nama, 'tipe' => $tipe]);
                flash('success', 'Kategori berhasil ditambahkan.');
                redirect('kategori.php');
            } catch (PDOException $e) {
                // kena unique, berarti udah ada
                $error = 'Kategori tersebut sudah ada.';
            }
        }
    }

    if ($action == 'delete') {
        $q = $pdo->prepare('DELETE FROM kategori WHERE id = :id');
        $q->execute(['id' => (int) $_POST['id']]);
        flash('success', 'Kategori berhasil dihapus.');
        redirect('kategori.php');
    }
}

$items = $pdo->query('SELECT * FROM kategori ORDER BY nama')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<div class="page-intro">
    <div><span class="eyebrow">MASTER DATA</span><h2>Kategori</h2><p>Kelola kategori yang tersedia untuk pengaduan dan aspirasi.</p></div>
</div>
<?php if ($error): ?>
    <div class="alert alert-danger">! <?= e($error) ?></div>
<?php endif; ?>
<div class="two-column">
    <form class="card form-card" method="post">
        <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="add">
        <div class="card-header">
            <div><span class="eyebrow">BARU</span><h3>Tambah Kategori</h3></div>
        </div>
        <div class="form-group"><label>Nama</label>
            <input name="nama" required placeholder="Contoh: Akademik">
        </div>
        <div class="form-group"><label>Digunakan untuk</label>
            <select name="tipe">
                <option value="keduanya">Pengaduan & Aspirasi</option><option value="pengaduan">Pengaduan</option><option value="aspirasi">Aspirasi</option>
            </select>
        </div>
        <button class="btn btn-primary btn-full">Tambah Kategori</button>
    </form>
    <div class="card table-card">
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Kategori</th>
                        <th>Tipe</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td><strong><?= e($item['nama']) ?></strong></td>
                            <td><?= e(ucfirst($item['tipe'])) ?></td>
                            <td>
                                <form method="post" data-confirm="Hapus kategori?">
                                    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= (int)$item['id'] ?>">
                                    <button class="btn btn-small btn-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
