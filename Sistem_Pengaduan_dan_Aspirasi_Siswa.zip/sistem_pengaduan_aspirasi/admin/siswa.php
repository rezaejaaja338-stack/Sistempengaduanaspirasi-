<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$pageTitle = 'Data Siswa';
$cari = trim($_GET['q'] ?? '');

$sql = 'SELECT s.*, u.username, u.email, u.status user_status FROM siswa s LEFT JOIN users u ON u.siswa_id = s.id';
if ($cari != '') {
    $q = $pdo->prepare($sql . ' WHERE s.nisn LIKE :q OR s.nama LIKE :q OR s.kelas LIKE :q ORDER BY s.nama');
    $q->execute(['q' => "%$cari%"]);
} else {
    $q = $pdo->query($sql . ' ORDER BY s.nama');
}
$data = $q->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="page-intro">
    <div><span class="eyebrow">ADMIN</span><h2>Data Siswa</h2><p>Daftar siswa yang terdaftar pada sistem.</p></div>
</div>
<form class="filter-card" method="get">
    <input name="q" placeholder="Cari NISN, nama, atau kelas..." value="<?= e($cari) ?>">
    <button class="btn btn-primary">Cari</button>
    <a class="btn btn-secondary" href="siswa.php">Reset</a>
</form>
<div class="card table-card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>NISN</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>Jurusan</th>
                    <th>Username</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $d): ?>
                    <tr>
                        <td><?= e($d['nisn']) ?></td>
                        <td><strong><?= e($d['nama']) ?></strong><small class="table-sub"><?= e($d['email']) ?></small></td>
                        <td><?= e($d['kelas']) ?></td>
                        <td><?= e($d['jurusan']) ?></td>
                        <td><?= e($d['username'] ?? '-') ?></td>
                        <td><span class="<?= ($d['user_status'] ?? $d['status']) === 'aktif' ? 'badge badge-green' : 'badge badge-red' ?>"><?= e($d['user_status'] ?? $d['status']) ?></span></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$data): ?>
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">Data siswa tidak ditemukan.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
