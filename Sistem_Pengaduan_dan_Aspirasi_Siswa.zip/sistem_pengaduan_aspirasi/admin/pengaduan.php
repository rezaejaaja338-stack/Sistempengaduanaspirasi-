<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$pageTitle = 'Data Pengaduan';
$status = $_GET['status'] ?? '';
$kategoriId = (int) ($_GET['kategori_id'] ?? 0);
$search = trim($_GET['q'] ?? '');
$from = $_GET['from'] ?? '';
$to = $_GET['to'] ?? '';

$daftarKategori = $pdo->query('SELECT id, nama FROM kategori ORDER BY nama')->fetchAll();

$where = ['1=1'];
$params = [];
if ($status != '') {
    $where[] = 'p.status = :status';
    $params['status'] = $status;
}
if ($kategoriId > 0) {
    $where[] = 'p.kategori_id = :kategori_id';
    $params['kategori_id'] = $kategoriId;
}
if ($search != '') {
    $where[] = '(p.judul LIKE :q OR p.isi LIKE :q OR c.nama LIKE :q)';
    $params['q'] = "%$search%";
}
if ($from != '') {
    $where[] = 'p.tanggal_pengaduan >= :from';
    $params['from'] = $from;
}
if ($to != '') {
    $where[] = 'p.tanggal_pengaduan <= :to';
    $params['to'] = $to;
}

$query = 'SELECT p.*, c.nama kategori, CASE WHEN p.anonim = 1 THEN "Anonim" ELSE COALESCE(s.nama, u.nama, "-") END reporter
        FROM pengaduan p
        LEFT JOIN kategori c ON c.id = p.kategori_id
        LEFT JOIN siswa s ON s.id = p.siswa_id
        LEFT JOIN users u ON u.id = p.created_by_user_id
        WHERE ' . implode(' AND ', $where) . ' ORDER BY p.created_at DESC';
$st = $pdo->prepare($query);
$st->execute($params);
$data = $st->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="page-intro split">
    <div><span class="eyebrow">ADMIN</span><h2>Data Pengaduan</h2><p>Kelola laporan, status, bukti foto, dan tanggapan siswa.</p></div>
</div>
<form class="filter-card" method="get">
    <input name="q" placeholder="Cari judul / isi..." value="<?= e($search) ?>">
    <select name="status">
        <option value="">Semua status</option>
        <?php foreach (['Baru','Diproses','Selesai','Ditolak'] as $s): ?>
            <option <?= $status === $s ? 'selected' : '' ?>><?= $s ?></option>
        <?php endforeach; ?>
    </select>
    <select name="kategori_id">
        <option value="0">Semua kategori</option>
        <?php foreach ($daftarKategori as $k): ?>
            <option value="<?= (int)$k['id'] ?>" <?= $kategoriId === (int)$k['id'] ? 'selected' : '' ?>><?= e($k['nama']) ?></option>
        <?php endforeach; ?>
    </select>
    <input type="date" name="from" value="<?= e($from) ?>">
    <input type="date" name="to" value="<?= e($to) ?>">
    <button class="btn btn-primary">Filter</button>
    <a class="btn btn-secondary" href="pengaduan.php">Reset</a>
</form>
<div class="card table-card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Pengaduan</th>
                    <th>Pelapor</th>
                    <th>Kategori</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $p): ?>
                    <tr>
                        <td><strong><?= e($p['judul']) ?></strong><small class="table-sub">#<?= (int)$p['id'] ?><?= $p['foto_bukti'] ? ' · 📷 Foto' : '' ?></small></td>
                        <td><?= e($p['reporter']) ?></td>
                        <td><?= e($p['kategori'] ?? '-') ?></td>
                        <td><?= format_date($p['tanggal_pengaduan']) ?></td>
                        <td><span class="<?= status_class($p['status']) ?>"><?= e($p['status']) ?></span></td>
                        <td>
                            <a class="btn btn-small btn-secondary" href="detail_pengaduan.php?id=<?= (int)$p['id'] ?>">Kelola</a></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$data): ?>
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">Tidak ada data yang sesuai.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
