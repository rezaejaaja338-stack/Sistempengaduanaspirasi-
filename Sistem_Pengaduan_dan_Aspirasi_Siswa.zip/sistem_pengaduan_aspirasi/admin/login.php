<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

// udah login ga perlu ke sini lagi
if (is_logged_in()) {
    if ($_SESSION['role'] == 'admin') redirect('../admin/dashboard.php');
    redirect('../siswa/dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    verify_csrf();

    $identity = trim($_POST['identity'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($identity == '' || $password == '') {
        $error = 'Username/email dan password wajib diisi.';
    } else {
        $stmt = $pdo->prepare('SELECT id, nama, username, email, password, role, siswa_id FROM users WHERE (username = :identity_user OR email = :identity_email) AND role = "admin" AND status = "aktif" LIMIT 1');
        $stmt->execute(['identity_user' => $identity, 'identity_email' => $identity]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int) $user['id'];
            $_SESSION['name'] = $user['nama'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['siswa_id'] = $user['siswa_id'];

            redirect('dashboard.php');
        }

        $error = 'Login gagal. Periksa username/email dan password Anda.';
    }
}
require_once __DIR__ . '/../includes/icons.php';
require_once __DIR__ . '/../includes/illustrations.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk Admin | SMK Strada Jakarta</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="login-page">
    <header class="login-top">
        <div class="container">
            <a class="brand" href="login.php">
                <img src="../assets/img/logo.jpg" alt="Logo SMK Strada Jakarta">
                <strong>SMK STRADA JAKARTA</strong>
            </a>
        </div>
    </header>

    <main class="login-main">
        <div class="login-wrap">
            <section class="login-brand-panel">
                <span class="eyebrow">Panel Admin Pengaduan &amp; Aspirasi</span>
                <h1>Setiap suara siswa, terkelola rapi.</h1>
                <p>Pantau laporan yang masuk, tindak lanjuti pengaduan, dan tanggapi aspirasi siswa SMK Strada Jakarta.</p>
                <ul class="feature-list">
                    <li><?= icon('check', 18) ?> Pantau semua pengaduan yang masuk beserta bukti foto.</li>
                    <li><?= icon('check', 18) ?> Ubah status dan beri tanggapan pada laporan.</li>
                    <li><?= icon('check', 18) ?> Kelola kategori dan cetak laporan periode.</li>
                </ul>
                <?= illustration_megaphone() ?>
            </section>

            <section class="login-form-panel">
                <div class="login-card">
                    <span class="eyebrow">Selamat datang</span>
                    <h2>Masuk sebagai Admin</h2>
                    <p class="muted">Khusus pengelola sistem. Gunakan akun admin untuk melanjutkan.</p>

                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-login"><?= icon('alert', 20) ?> <?= e($error) ?></div>
                    <?php endif; ?>

                    <form method="post" autocomplete="off">
                        <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">

                        <label for="identity">Username / Email</label>
                        <input id="identity" name="identity" type="text" placeholder="Masukkan username atau email" required value="<?= old('identity') ?>">

                        <label for="password">Password</label>
                        <div class="password-field">
                            <input id="password" name="password" type="password" placeholder="Masukkan password" required>
                            <button type="button" class="password-toggle" data-target="password">Lihat</button>
                        </div>

                        <button class="btn btn-primary btn-lg btn-full" type="submit">Masuk ke Dashboard <?= icon('arrow', 20) ?></button>
                    </form>

                    <div class="demo-accounts">
                        <strong>Akun demo</strong>
                        <span>Admin: <b>admin</b> / <b>admin123</b></span>
                    </div>
                </div>
            </section>
        </div>
    </main>
<script src="../assets/js/script.js"></script>
</body>
</html>
