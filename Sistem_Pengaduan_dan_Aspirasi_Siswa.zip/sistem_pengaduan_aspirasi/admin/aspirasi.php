<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$pageTitle = 'Data Aspirasi';
$status = $_GET['status'] ?? '';
$cari = trim($_GET['q'] ?? '');

$where = ['1=1'];
$params = [];
if ($status != '') {
    $where[] = 'a.status = :status';
    $params['status'] = $status;
}
if ($cari != '') {
    $where[] = '(a.judul LIKE :q OR a.isi LIKE :q OR c.nama LIKE :q)';
    $params['q'] = "%$cari%";
}

$query = 'SELECT a.*, c.nama kategori, CASE WHEN a.anonim = 1 THEN "Anonim" ELSE COALESCE(s.nama, u.nama, "-") END reporter
        FROM aspirasi a
        LEFT JOIN kategori c ON c.id = a.kategori_id
        LEFT JOIN siswa s ON s.id = a.siswa_id
        LEFT JOIN users u ON u.id = a.created_by_user_id
        WHERE ' . implode(' AND ', $where) . ' ORDER BY a.created_at DESC';
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$data = $stmt->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="page-intro">
    <div><span class="eyebrow">ADMIN</span><h2>Data Aspirasi</h2><p>Kelola saran dan masukan yang dikirim siswa.</p></div>
</div>
<form class="filter-card" method="get">
    <input name="q" placeholder="Cari aspirasi..." value="<?= e($cari) ?>">
    <select name="status">
        <option value="">Semua status</option>
        <?php foreach (['Baru','Diproses','Selesai','Ditolak'] as $s): ?>
            <option <?= $status === $s ? 'selected' : '' ?>><?= $s ?></option>
        <?php endforeach; ?>
    </select>
    <button class="btn btn-primary">Filter</button>
    <a class="btn btn-secondary" href="aspirasi.php">Reset</a>
</form>
<div class="card table-card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Aspirasi</th>
                    <th>Pengirim</th>
                    <th>Kategori</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $a): ?>
                    <tr>
                        <td><strong><?= e($a['judul']) ?></strong><small class="table-sub">#<?= (int)$a['id'] ?></small></td>
                        <td><?= e($a['reporter']) ?></td>
                        <td><?= e($a['kategori'] ?? '-') ?></td>
                        <td><?= format_date($a['tanggal_aspirasi']) ?></td>
                        <td><span class="<?= status_class($a['status']) ?>"><?= e($a['status']) ?></span></td>
                        <td>
                            <a class="btn btn-small btn-secondary" href="detail_aspirasi.php?id=<?= (int)$a['id'] ?>">Kelola</a></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$data): ?>
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">Belum ada aspirasi.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
