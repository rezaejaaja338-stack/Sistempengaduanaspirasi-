<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$pageTitle = 'Profil Admin';
$id = (int) $_SESSION['user_id'];
$error = '';

$q = $pdo->prepare('SELECT * FROM users WHERE id = :id AND role = "admin"');
$q->execute(['id' => $id]);
$user = $q->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    verify_csrf();
    $nama = trim($_POST['nama'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($nama == '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Nama dan email harus benar.';
    } else {
        if ($password != '') {
            $q = $pdo->prepare('UPDATE users SET nama = :nama, email = :email, password = :password WHERE id = :id');
            $q->execute(['nama' => $nama, 'email' => $email, 'password' => password_hash($password, PASSWORD_DEFAULT), 'id' => $id]);
        } else {
            $q = $pdo->prepare('UPDATE users SET nama = :nama, email = :email WHERE id = :id');
            $q->execute(['nama' => $nama, 'email' => $email, 'id' => $id]);
        }
        $_SESSION['name'] = $nama;
        flash('success', 'Profil admin berhasil diperbarui.');
        redirect('profil.php');
    }
}

include __DIR__ . '/../includes/header.php';
?>
<div class="page-intro">
    <div><span class="eyebrow">AKUN ADMIN</span><h2>Profil Admin</h2><p>Kelola informasi akun administrator.</p></div>
</div>
<?php if($error): ?>
    <div class="alert alert-danger">! <?=e($error)?></div>
<?php endif; ?>
<form method="post" class="card form-card">
    <input type="hidden" name="_csrf" value="<?=e(csrf_token())?>">
    <div class="form-grid">
        <div class="form-group"><label>Nama</label>
            <input name="nama" value="<?=e($user['nama'])?>" required>
        </div>
        <div class="form-group"><label>Username</label>
            <input value="<?=e($user['username'])?>" disabled>
        </div>
        <div class="form-group"><label>Email</label>
            <input name="email" type="email" value="<?=e($user['email'])?>" required>
        </div>
        <div class="form-group"><label>Role</label>
            <input value="Administrator" disabled>
        </div>
    </div>
    <div class="form-group"><label>Password Baru</label>
        <input type="password" name="password" minlength="6" placeholder="Kosongkan jika tidak diubah">
    </div>
    <div class="form-actions">
        <button class="btn btn-primary">Simpan Perubahan</button>
    </div>
</form>
<?php include __DIR__.'/../includes/footer.php'; ?>
