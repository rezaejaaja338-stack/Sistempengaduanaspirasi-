<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$id = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare('SELECT p.*, c.nama kategori, CASE WHEN p.anonim = 1 THEN "Anonim" ELSE COALESCE(s.nama, u.nama, "-") END reporter, s.nisn
    FROM pengaduan p
    LEFT JOIN kategori c ON c.id = p.kategori_id
    LEFT JOIN siswa s ON s.id = p.siswa_id
    LEFT JOIN users u ON u.id = p.created_by_user_id
    WHERE p.id = :id');
$stmt->execute(['id' => $id]);
$item = $stmt->fetch();

if (!$item) {
    flash('error', 'Pengaduan tidak ditemukan.');
    redirect('pengaduan.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action == 'update') {
        $statusBaru = $_POST['status'] ?? 'Baru';
        if (!in_array($statusBaru, ['Baru', 'Diproses', 'Selesai', 'Ditolak'])) {
            $statusBaru = 'Baru';
        }
        $pdo->prepare('UPDATE pengaduan SET status = :status, updated_at = NOW() WHERE id = :id')
            ->execute(['status' => $statusBaru, 'id' => $id]);

        $tanggapan = trim($_POST['tanggapan'] ?? '');
        if ($tanggapan != '') {
            $pdo->prepare('INSERT INTO tanggapan_pengaduan (pengaduan_id, admin_id, tanggapan) VALUES (:pengaduan_id, :admin_id, :tanggapan)')
                ->execute(['pengaduan_id' => $id, 'admin_id' => (int) $_SESSION['user_id'], 'tanggapan' => $tanggapan]);
        }

        flash('success', 'Pengaduan berhasil diperbarui.');
        redirect('detail_pengaduan.php?id=' . $id);
    }

    if ($action == 'delete') {
        // fotonya dibuang juga
        $foto = $item['foto_bukti'];
        $pdo->prepare('DELETE FROM pengaduan WHERE id = :id')->execute(['id' => $id]);
        hapus_foto($foto);
        flash('success', 'Pengaduan berhasil dihapus.');
        redirect('pengaduan.php');
    }
}

$stmt = $pdo->prepare('SELECT r.*, u.nama admin_name FROM tanggapan_pengaduan r LEFT JOIN users u ON u.id = r.admin_id WHERE r.pengaduan_id = :id ORDER BY r.created_at ASC');
$stmt->execute(['id' => $id]);
$daftarTanggapan = $stmt->fetchAll();

$pageTitle = 'Kelola Pengaduan';
include __DIR__ . '/../includes/header.php';
?>
<div class="page-intro split">
    <div><span class="eyebrow">LAPORAN #<?= $id ?></span><h2><?= e($item['judul']) ?></h2><p>Pelapor: <strong><?= e($item['reporter']) ?></strong> <?= $item['nisn'] ? '· NISN ' . e($item['nisn']) : '' ?></p></div>
    <a class="btn btn-secondary" href="pengaduan.php">← Kembali</a></div>
<div class="detail-grid admin-detail">
    <div class="card detail-card">
        <div class="detail-top"><span class="<?= status_class($item['status']) ?>"><?= e($item['status']) ?></span>
            <?php if ($item['anonim']): ?>
                <span class="badge badge-dark">Pengaduan Anonim</span>
            <?php endif; ?>
        </div>
        <div class="detail-meta">
            <div><small>Kategori</small><strong><?= e($item['kategori'] ?? '-') ?></strong></div>
            <div><small>Lokasi</small><strong><?= e($item['lokasi'] ?: '-') ?></strong></div>
            <div><small>Tanggal</small><strong><?= format_date($item['tanggal_pengaduan']) ?></strong></div>
        </div>
        <hr>
        <h3>Isi Laporan</h3><p class="detail-text"><?= nl2br(e($item['isi'])) ?></p>
        <?php if ($item['foto_bukti']): ?>
            <div class="evidence"><small>Foto Bukti</small><img src="../uploads/pengaduan/<?= e($item['foto_bukti']) ?>" alt="Bukti pengaduan"></div>
        <?php endif; ?>
    </div>
    <div>
        <div class="card form-card">
            <div class="card-header">
                <div><span class="eyebrow">TINDAK LANJUT</span><h3>Update Laporan</h3></div>
            </div>
            <form method="post">
                <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="update">
                <div class="form-group"><label>Status</label>
                    <select name="status">
                        <?php foreach (['Baru','Diproses','Selesai','Ditolak'] as $s): ?>
                            <option <?= $item['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group"><label>Tanggapan</label><textarea name="tanggapan" rows="6" placeholder="Tulis tanggapan atau tindak lanjut..."></textarea></div>
                <button class="btn btn-primary btn-full">Simpan Perubahan</button>
            </form>
        </div>
        <div class="card">
            <div class="card-header">
                <div><span class="eyebrow">RIWAYAT</span><h3>Tanggapan</h3></div>
            </div>
            <?php if (!$daftarTanggapan): ?>
                <div class="empty-state">Belum ada tanggapan.</div>
            <?php else: ?>
                <div class="timeline">
                    <?php foreach ($daftarTanggapan as $r): ?>
                        <div class="timeline-item"><span class="timeline-dot"></span>
                            <div><strong><?= e($r['admin_name'] ?? 'Admin') ?></strong><small><?= format_datetime($r['created_at']) ?></small><p><?= nl2br(e($r['tanggapan'])) ?></p></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <form method="post" data-confirm="Hapus pengaduan ini?">
            <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="delete">
            <button class="btn btn-danger btn-full">Hapus Pengaduan</button>
        </form>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
