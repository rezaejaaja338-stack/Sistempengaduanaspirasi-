<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$pageTitle = 'Dashboard Admin';

// hitung2 buat kartu di atas
$jml = [
    'siswa' => $pdo->query('SELECT COUNT(*) FROM siswa WHERE status = "aktif"')->fetchColumn(),
    'pengaduan' => $pdo->query('SELECT COUNT(*) FROM pengaduan')->fetchColumn(),
    'baru' => $pdo->query('SELECT COUNT(*) FROM pengaduan WHERE status = "Baru"')->fetchColumn(),
    'diproses' => $pdo->query('SELECT COUNT(*) FROM pengaduan WHERE status = "Diproses"')->fetchColumn(),
    'selesai' => $pdo->query('SELECT COUNT(*) FROM pengaduan WHERE status = "Selesai"')->fetchColumn(),
    'aspirasi' => $pdo->query('SELECT COUNT(*) FROM aspirasi')->fetchColumn(),
    'aspirasi_baru' => $pdo->query('SELECT COUNT(*) FROM aspirasi WHERE status = "Baru"')->fetchColumn(),
];
foreach ($jml as $k => $v) {
    $jml[$k] = (int)$v;
}

$dataGrafik = $pdo->query('SELECT c.nama, COUNT(p.id) total FROM kategori c LEFT JOIN pengaduan p ON p.kategori_id = c.id GROUP BY c.id, c.nama ORDER BY total DESC')->fetchAll();
$terbaru = $pdo->query('SELECT p.id, p.judul, p.status, p.anonim, p.created_at, c.nama kategori FROM pengaduan p LEFT JOIN kategori c ON c.id = p.kategori_id ORDER BY p.created_at DESC LIMIT 7')->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<section class="hero">
    <div>
        <span class="eyebrow">Panel Admin Pengaduan &amp; Aspirasi</span>
        <h1>Setiap suara siswa, terkelola rapi.</h1>
        <p>Selamat datang, <?= e($_SESSION['name']) ?>. Pantau laporan yang masuk, tindak lanjuti pengaduan, dan tanggapi aspirasi siswa SMK Strada Jakarta dari satu tempat.</p>
        <div class="hero-actions">
            <a class="btn btn-primary btn-lg" href="pengaduan.php"><?= icon('doc', 22) ?> Kelola Pengaduan <?= icon('arrow', 20) ?></a>
            <a class="btn btn-lime btn-lg" href="laporan.php"><?= icon('chart', 22) ?> Lihat Laporan <?= icon('arrow', 20) ?></a>
        </div>
    </div>
    <div class="hero-art">
        <?= illustration_megaphone() ?>
        <div class="hero-note">Suara<br>Siswa<br>Untuk<br>Sekolah</div>
    </div>
</section>

<div class="stats-grid admin-stats">
    <a class="stat-card" href="siswa.php">
        <span class="stat-icon"><?= icon('users', 28) ?></span>
        <small>Total Siswa</small><strong><?= $jml['siswa'] ?></strong>
        <span class="stat-arrow"><?= icon('arrow', 18) ?></span>
    </a>
    <a class="stat-card" href="pengaduan.php">
        <span class="stat-icon"><?= icon('doc', 28) ?></span>
        <small>Total Pengaduan</small><strong><?= $jml['pengaduan'] ?></strong>
        <span class="stat-arrow"><?= icon('arrow', 18) ?></span>
    </a>
    <a class="stat-card" href="pengaduan.php?status=Baru">
        <span class="stat-icon"><?= icon('bell', 28) ?></span>
        <small>Laporan Baru</small><strong><?= $jml['baru'] ?></strong>
        <span class="stat-arrow"><?= icon('arrow', 18) ?></span>
    </a>
    <a class="stat-card" href="pengaduan.php?status=Selesai">
        <span class="stat-icon"><?= icon('check', 28) ?></span>
        <small>Selesai</small><strong><?= $jml['selesai'] ?></strong>
        <span class="stat-arrow"><?= icon('arrow', 18) ?></span>
    </a>
    <a class="stat-card" href="aspirasi.php">
        <span class="stat-icon"><?= icon('bulb', 28) ?></span>
        <small>Total Aspirasi</small><strong><?= $jml['aspirasi'] ?></strong>
        <span class="stat-arrow"><?= icon('arrow', 18) ?></span>
    </a>
    <a class="stat-card" href="aspirasi.php">
        <span class="stat-icon"><?= icon('alert', 28) ?></span>
        <small>Aspirasi Baru</small><strong><?= $jml['aspirasi_baru'] ?></strong>
        <span class="stat-arrow"><?= icon('arrow', 18) ?></span>
    </a>
</div>

<div class="dash-grid">
    <div class="card table-card table-compact">
        <div class="card-header">
            <h3><?= icon('doc', 30) ?> Pengaduan Terbaru</h3>
            <a href="pengaduan.php">Lihat Semua <?= icon('arrow', 18) ?></a>
        </div>
        <?php if (!$terbaru): ?>
            <div class="empty-state">Belum ada pengaduan yang masuk.</div>
        <?php else: ?>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>No</th><th>Judul Laporan</th><th>Tanggal</th><th>Status</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ($terbaru as $i => $item): ?>
                        <tr>
                            <td><?= str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) ?></td>
                            <td><strong><?= e($item['judul']) ?></strong><small class="table-sub"><?= $item['anonim'] ? 'Anonim' : 'Siswa terdaftar' ?> · <?= e($item['kategori'] ?? 'Tanpa kategori') ?></small></td>
                            <td><?= format_date($item['created_at']) ?></td>
                            <td><span class="<?= status_class($item['status']) ?>"><?= e($item['status']) ?></span></td>
                            <td><a class="row-arrow" href="detail_pengaduan.php?id=<?= (int) $item['id'] ?>" aria-label="Kelola pengaduan"><?= icon('arrow', 20) ?></a></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <div class="cta-card">
        <span class="cta-icon"><?= icon('chart', 26) ?></span>
        <h3>Pengaduan per kategori</h3>
        <div class="bar-chart">
            <?php $terbesar = max(array_column($dataGrafik, 'total') ?: [1]); foreach ($dataGrafik as $r): ?>
                <div class="bar-row">
                    <div class="bar-label"><span><?= e($r['nama']) ?></span><b><?= (int) $r['total'] ?></b></div>
                    <div class="bar-track"><span style="width: <?= $terbesar ? ((int) $r['total'] / $terbesar * 100) : 0 ?>%"></span></div>
                </div>
            <?php endforeach; ?>
        </div>
        <a class="btn btn-primary btn-lg" href="kategori.php"><?= icon('tag', 20) ?> Kelola Kategori <?= icon('arrow', 20) ?></a>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
