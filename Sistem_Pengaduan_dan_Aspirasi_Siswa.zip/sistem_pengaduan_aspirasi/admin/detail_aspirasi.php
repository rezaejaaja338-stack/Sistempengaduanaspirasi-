<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('admin');

$id = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare('SELECT a.*, c.nama kategori, CASE WHEN a.anonim = 1 THEN "Anonim" ELSE COALESCE(s.nama, u.nama, "-") END reporter
    FROM aspirasi a
    LEFT JOIN kategori c ON c.id = a.kategori_id
    LEFT JOIN siswa s ON s.id = a.siswa_id
    LEFT JOIN users u ON u.id = a.created_by_user_id
    WHERE a.id = :id');
$stmt->execute(['id' => $id]);
$item = $stmt->fetch();

if (!$item) {
    flash('error', 'Aspirasi tidak ditemukan.');
    redirect('aspirasi.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action == 'update') {
        $statusBaru = $_POST['status'] ?? 'Baru';
        if (!in_array($statusBaru, ['Baru', 'Diproses', 'Selesai', 'Ditolak'])) {
            $statusBaru = 'Baru';
        }
        $pdo->prepare('UPDATE aspirasi SET status = :status, updated_at = NOW() WHERE id = :id')
            ->execute(['status' => $statusBaru, 'id' => $id]);

        $tanggapan = trim($_POST['tanggapan'] ?? '');
        if ($tanggapan != '') {
            $pdo->prepare('INSERT INTO tanggapan_aspirasi (aspirasi_id, admin_id, tanggapan) VALUES (:aspirasi_id, :admin_id, :tanggapan)')
                ->execute(['aspirasi_id' => $id, 'admin_id' => (int) $_SESSION['user_id'], 'tanggapan' => $tanggapan]);
        }

        flash('success', 'Aspirasi berhasil diperbarui.');
        redirect('detail_aspirasi.php?id=' . $id);
    }

    if ($action == 'delete') {
        $pdo->prepare('DELETE FROM aspirasi WHERE id = :id')->execute(['id' => $id]);
        flash('success', 'Aspirasi berhasil dihapus.');
        redirect('aspirasi.php');
    }
}

$stmt = $pdo->prepare('SELECT r.*, u.nama admin_name FROM tanggapan_aspirasi r LEFT JOIN users u ON u.id = r.admin_id WHERE r.aspirasi_id = :id ORDER BY r.created_at ASC');
$stmt->execute(['id' => $id]);
$daftarTanggapan = $stmt->fetchAll();

$pageTitle = 'Kelola Aspirasi';
include __DIR__ . '/../includes/header.php';
?>
<div class="page-intro split">
    <div><span class="eyebrow">ASPIRASI #<?= $id ?></span><h2><?= e($item['judul']) ?></h2><p>Pengirim: <strong><?= e($item['reporter']) ?></strong></p></div>
    <a class="btn btn-secondary" href="aspirasi.php">← Kembali</a></div>
<div class="detail-grid admin-detail">
    <div class="card detail-card">
        <div class="detail-top"><span class="<?= status_class($item['status']) ?>"><?= e($item['status']) ?></span>
            <?php if ($item['anonim']): ?>
                <span class="badge badge-dark">Anonim</span>
            <?php endif; ?>
        </div>
        <div class="detail-meta">
            <div><small>Kategori</small><strong><?= e($item['kategori'] ?? '-') ?></strong></div>
            <div><small>Tanggal</small><strong><?= format_date($item['tanggal_aspirasi']) ?></strong></div>
        </div>
        <hr>
        <h3>Isi Aspirasi</h3><p class="detail-text"><?= nl2br(e($item['isi'])) ?></p></div>
    <div>
        <div class="card form-card">
            <div class="card-header">
                <div><span class="eyebrow">RESPON</span><h3>Update Aspirasi</h3></div>
            </div>
            <form method="post">
                <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="action" value="update">
                <div class="form-group"><label>Status</label>
                    <select name="status">
                        <?php foreach (['Baru','Diproses','Selesai','Ditolak'] as $s): ?>
                            <option <?= $item['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group"><label>Tanggapan</label><textarea name="tanggapan" rows="6" placeholder="Tulis tanggapan..."></textarea></div>
                <button class="btn btn-primary btn-full">Simpan Perubahan</button>
            </form>
        </div>
        <div class="card">
            <div class="card-header">
                <div><span class="eyebrow">RIWAYAT</span><h3>Tanggapan</h3></div>
            </div>
            <?php if (!$daftarTanggapan): ?>
                <div class="empty-state">Belum ada tanggapan.</div>
            <?php else: ?>
                <div class="timeline">
                    <?php foreach ($daftarTanggapan as $r): ?>
                        <div class="timeline-item"><span class="timeline-dot"></span>
                            <div><strong><?= e($r['admin_name'] ?? 'Admin') ?></strong><small><?= format_datetime($r['created_at']) ?></small><p><?= nl2br(e($r['tanggapan'])) ?></p></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <form method="post" data-confirm="Hapus aspirasi ini?">
            <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="delete">
            <button class="btn btn-danger btn-full">Hapus Aspirasi</button>
        </form>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
