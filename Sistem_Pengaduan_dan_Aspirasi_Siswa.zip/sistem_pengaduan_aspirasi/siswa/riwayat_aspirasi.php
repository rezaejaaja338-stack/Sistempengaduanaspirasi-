<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('siswa');

$pageTitle = 'Riwayat Aspirasi';
$q = $pdo->prepare('SELECT a.*, c.nama AS kategori FROM aspirasi a LEFT JOIN kategori c ON c.id = a.kategori_id WHERE a.created_by_user_id = :user_id ORDER BY a.created_at DESC');
$q->execute(['user_id' => (int) $_SESSION['user_id']]);
$items = $q->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="page-intro split">
    <div><span class="eyebrow">RIWAYAT</span><h2>Aspirasi Saya</h2><p>Semua ide dan saran yang pernah kamu kirimkan.</p></div>
    <a class="btn btn-primary" href="buat_aspirasi.php">+ Aspirasi Baru</a></div>
<div class="tabs"><a href="riwayat_pengaduan.php">Pengaduan</a><a href="riwayat_aspirasi.php" class="active">Aspirasi</a></div>
<div class="card table-card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Judul</th>
                    <th>Kategori</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                    <tr>
                        <td><strong><?= e($item['judul']) ?></strong><small class="table-sub">ID #<?= (int) $item['id'] ?> <?= $item['anonim'] ? '· Anonim' : '' ?></small></td>
                        <td><?= e($item['kategori'] ?? '-') ?></td>
                        <td><?= format_date($item['tanggal_aspirasi']) ?></td>
                        <td><span class="<?= status_class($item['status']) ?>"><?= e($item['status']) ?></span></td>
                        <td>
                            <a class="btn btn-small btn-secondary" href="detail_aspirasi.php?id=<?= (int) $item['id'] ?>">Detail</a></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$items): ?>
                    <tr>
                        <td colspan="5">
                            <div class="empty-state">Belum ada aspirasi.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
