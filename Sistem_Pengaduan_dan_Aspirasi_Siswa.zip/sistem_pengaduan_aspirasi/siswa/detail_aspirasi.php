<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('siswa');

$id = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare('SELECT a.*, c.nama AS kategori FROM aspirasi a LEFT JOIN kategori c ON c.id = a.kategori_id WHERE a.id = :id AND a.created_by_user_id = :user_id LIMIT 1');
$stmt->execute(['id' => $id, 'user_id' => (int) $_SESSION['user_id']]);
$item = $stmt->fetch();

if (!$item) {
    flash('error', 'Aspirasi tidak ditemukan.');
    redirect('riwayat_aspirasi.php');
}

$stmt = $pdo->prepare('SELECT r.*, u.nama AS admin_name FROM tanggapan_aspirasi r LEFT JOIN users u ON u.id = r.admin_id WHERE r.aspirasi_id = :id ORDER BY r.created_at ASC');
$stmt->execute(['id' => $id]);
$daftarTanggapan = $stmt->fetchAll();

$pageTitle = 'Detail Aspirasi';
include __DIR__ . '/../includes/header.php';
?>
<div class="page-intro split">
    <div><span class="eyebrow">ASPIRASI #<?= $id ?></span><h2><?= e($item['judul']) ?></h2><p>Dikirim <?= format_datetime($item['created_at']) ?>.</p></div>
    <a class="btn btn-secondary" href="riwayat_aspirasi.php">← Kembali</a></div>
<div class="detail-grid">
    <div class="card detail-card">
        <div class="detail-top"><span class="<?= status_class($item['status']) ?>"><?= e($item['status']) ?></span>
            <?php if ($item['anonim']): ?>
                <span class="badge badge-dark">Anonim</span>
            <?php endif; ?>
        </div>
        <div class="detail-meta">
            <div><small>Kategori</small><strong><?= e($item['kategori'] ?? '-') ?></strong></div>
            <div><small>Tanggal</small><strong><?= format_date($item['tanggal_aspirasi']) ?></strong></div>
        </div>
        <hr>
        <h3>Isi Aspirasi</h3><p class="detail-text"><?= nl2br(e($item['isi'])) ?></p></div>
    <div class="card">
        <div class="card-header">
            <div><span class="eyebrow">RESPON SEKOLAH</span><h3>Tanggapan Admin</h3></div>
        </div>
        <?php if (!$daftarTanggapan): ?>
            <div class="empty-state">Belum ada tanggapan.</div>
        <?php else: ?>
            <div class="timeline">
                <?php foreach ($daftarTanggapan as $t): ?>
                    <div class="timeline-item"><span class="timeline-dot"></span>
                        <div><strong><?= e($t['admin_name'] ?? 'Admin') ?></strong><small><?= format_datetime($t['created_at']) ?></small><p><?= nl2br(e($t['tanggapan'])) ?></p></div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
