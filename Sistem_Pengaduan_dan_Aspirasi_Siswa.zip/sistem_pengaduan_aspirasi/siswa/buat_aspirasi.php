<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('siswa');

$pageTitle = 'Buat Aspirasi';
$err = '';
$daftarKategori = $pdo->query("SELECT id, nama FROM kategori WHERE tipe IN ('aspirasi', 'keduanya') ORDER BY nama")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    verify_csrf();

    $kategori = (int) ($_POST['kategori_id'] ?? 0);
    $judul = trim($_POST['judul'] ?? '');
    $isi = trim($_POST['isi'] ?? '');
    $anonim = isset($_POST['anonim']) ? 1 : 0;

    if ($kategori <= 0 || $judul == '' || $isi == '') {
        $err = 'Kategori, judul, dan isi aspirasi wajib diisi.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO aspirasi (siswa_id, created_by_user_id, kategori_id, judul, isi, tanggal_aspirasi, anonim, status) VALUES (:siswa_id, :user_id, :kategori_id, :judul, :isi, CURDATE(), :anonim, "Baru")');
        $stmt->execute([
            'siswa_id' => $anonim ? null : (int) $_SESSION['siswa_id'],
            'user_id' => (int) $_SESSION['user_id'],
            'kategori_id' => $kategori,
            'judul' => $judul,
            'isi' => $isi,
            'anonim' => $anonim
        ]);

        flash('success', 'Aspirasi berhasil dikirim. Terima kasih sudah memberikan masukan.');
        redirect('riwayat_aspirasi.php');
    }
}

include __DIR__ . '/../includes/header.php';
?>
<div class="page-intro">
    <div><span class="eyebrow">SUARA SISWA</span><h2>Sampaikan Aspirasi</h2><p>Berikan ide, saran, atau masukan yang dapat membuat sekolah menjadi lebih baik.</p></div>
</div>
<?php if ($err): ?>
    <div class="alert alert-danger">! <?= e($err) ?></div>
<?php endif; ?>
<form method="post" class="card form-card">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
    <div class="form-grid">
        <div class="form-group"><label>Kategori <span>*</span></label>
            <select name="kategori_id" required>
                <option value="">Pilih kategori</option>
                <?php foreach ($daftarKategori as $k): ?>
                    <option value="<?= (int) $k['id'] ?>" <?= (($_POST['kategori_id'] ?? '') == $k['id']) ? 'selected' : '' ?>><?= e($k['nama']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group"><label>Judul Aspirasi <span>*</span></label>
            <input name="judul" maxlength="150" required placeholder="Contoh: Penambahan tempat sampah" value="<?= old('judul') ?>">
        </div>
    </div>
    <div class="form-group"><label>Isi Aspirasi <span>*</span></label><textarea name="isi" rows="8" maxlength="2000" required placeholder="Tuliskan ide atau saran kamu..."><?= old('isi') ?></textarea></div>
    <label class="check-card">
    <input type="checkbox" name="anonim" value="1" <?= isset($_POST['anonim']) ? 'checked' : '' ?>>
    <span><strong>Kirim sebagai anonim</strong><small>Nama tidak ditampilkan pada tampilan aspirasi.</small></span></label>
    <div class="form-actions">
        <a class="btn btn-secondary" href="dashboard.php">Batal</a>
        <button class="btn btn-primary">Kirim Aspirasi →</button>
    </div>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
