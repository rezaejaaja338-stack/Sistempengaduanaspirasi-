<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('siswa');

$pageTitle = 'Profil Siswa';
$userId = (int) $_SESSION['user_id'];
$stmt = $pdo->prepare('SELECT u.*, s.nisn, s.kelas, s.jurusan FROM users u LEFT JOIN siswa s ON s.id = u.siswa_id WHERE u.id = :id');
$stmt->execute(['id' => $userId]);
$user = $stmt->fetch();
$error = '';

if ($_SERVER['REQUEST_METHOD'] =='POST') {
    verify_csrf();
    $nama = trim($_POST['nama'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($nama =='' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Nama dan email harus diisi dengan benar.';
    } else {
        if ($password != '') {
            $stmt = $pdo->prepare('UPDATE users SET nama = :nama, email = :email, password = :password WHERE id = :id');
            $stmt->execute(['nama' => $nama, 'email' => $email, 'password' => password_hash($password, PASSWORD_DEFAULT), 'id' => $userId]);
        } else {
            $stmt = $pdo->prepare('UPDATE users SET nama = :nama, email = :email WHERE id = :id');
            $stmt->execute(['nama' => $nama, 'email' => $email, 'id' => $userId]);
        }

        $_SESSION['name'] = $nama;
        flash('success', 'Profil berhasil diperbarui.');
        redirect('profil.php');
    }
}

include __DIR__ . '/../includes/header.php';
?>
<div class="page-intro">
    <div><span class="eyebrow">AKUN</span><h2>Profil Siswa</h2><p>Perbarui informasi akun dan password jika diperlukan.</p></div>
</div>
<?php if ($error): ?>
    <div class="alert alert-danger">! <?= e($error) ?></div>
<?php endif; ?>
<form method="post" class="card form-card">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
    <div class="form-grid">
        <div class="form-group"><label>Nama Lengkap</label>
            <input name="nama" required value="<?= e($user['nama']) ?>">
        </div>
        <div class="form-group"><label>Username</label>
            <input value="<?= e($user['username']) ?>" disabled>
        </div>
        <div class="form-group"><label>Email</label>
            <input name="email" type="email" required value="<?= e($user['email']) ?>">
        </div>
        <div class="form-group"><label>NISN</label>
            <input value="<?= e($user['nisn'] ?? '-') ?>" disabled>
        </div>
        <div class="form-group"><label>Kelas</label>
            <input value="<?= e($user['kelas'] ?? '-') ?>" disabled>
        </div>
        <div class="form-group"><label>Jurusan</label>
            <input value="<?= e($user['jurusan'] ?? '-') ?>" disabled>
        </div>
    </div>
    <div class="form-group"><label>Password Baru <small>(kosongkan jika tidak ingin mengubah)</small></label>
        <input type="password" name="password" minlength="6">
    </div>
    <div class="form-actions">
        <button class="btn btn-primary">Simpan Perubahan</button>
    </div>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
