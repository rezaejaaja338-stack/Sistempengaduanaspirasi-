<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('siswa');

$pageTitle = 'Buat Pengaduan';
$err = '';
$daftarKategori = $pdo->query("SELECT id, nama FROM kategori WHERE tipe IN ('pengaduan', 'keduanya') ORDER BY nama")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    verify_csrf();

    $kategori = (int) ($_POST['kategori_id'] ?? 0);
    $judul = trim($_POST['judul'] ?? '');
    $isi = trim($_POST['isi'] ?? '');
    $lokasi = trim($_POST['lokasi'] ?? '');
    $anonim = isset($_POST['anonim']) ? 1 : 0;
    $foto = null;

    if ($kategori <= 0 || $judul == '' || $isi == '') {
        $err = 'Kategori, judul, dan isi pengaduan wajib diisi.';
    } else {
        try {
            $foto = upload_foto($_FILES['foto'] ?? []);

            $stmt = $pdo->prepare('INSERT INTO pengaduan (siswa_id, created_by_user_id, kategori_id, judul, isi, lokasi, tanggal_pengaduan, foto_bukti, anonim, status) VALUES (:siswa_id, :user_id, :kategori_id, :judul, :isi, :lokasi, CURDATE(), :foto, :anonim, "Baru")');
            $stmt->execute([
                'siswa_id' => $anonim ? null : (int) $_SESSION['siswa_id'],
                'user_id' => (int) $_SESSION['user_id'],
                'kategori_id' => $kategori,
                'judul' => $judul,
                'isi' => $isi,
                'lokasi' => $lokasi,
                'foto' => $foto,
                'anonim' => $anonim
            ]);

            flash('success', 'Pengaduan berhasil dikirim dan masuk ke antrean admin.');
            redirect('riwayat_pengaduan.php');
        } catch (Throwable $e) {
            // insert gagal -> hapus foto yg udah keupload
            if ($foto) hapus_foto($foto);
            $err = $e->getMessage();
        }
    }
}

include __DIR__ . '/../includes/header.php';
?>
<div class="page-intro">
    <div><span class="eyebrow">LAPORAN BARU</span><h2>Sampaikan Pengaduan</h2><p>Gunakan formulir ini untuk melaporkan fasilitas, kejadian, atau masalah di lingkungan sekolah.</p></div>
</div>
<?php if ($err): ?>
    <div class="alert alert-danger">! <?= e($err) ?></div>
<?php endif; ?>
<form method="post" enctype="multipart/form-data" class="card form-card">
    <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
    <div class="form-grid">
        <div class="form-group">
            <label for="kategori_id">Kategori <span>*</span></label>
            <select id="kategori_id" name="kategori_id" required>
                <option value="">Pilih kategori</option>
                <?php foreach ($daftarKategori as $k): ?>
                    <option value="<?= (int) $k['id'] ?>" <?= (($_POST['kategori_id'] ?? '') == $k['id']) ? 'selected' : '' ?>><?= e($k['nama']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="lokasi">Lokasi Kejadian</label>
            <input id="lokasi" name="lokasi" type="text" placeholder="Contoh: Ruang XI RPL 1" value="<?= old('lokasi') ?>">
        </div>
    </div>
    <div class="form-group">
        <label for="judul">Judul Pengaduan <span>*</span></label>
        <input id="judul" name="judul" type="text" maxlength="150" placeholder="Contoh: Lampu kelas XI RPL 1 mati" required value="<?= old('judul') ?>">
    </div>
    <div class="form-group">
        <label for="isi">Isi Pengaduan <span>*</span></label>
        <textarea id="isi" name="isi" rows="7" maxlength="2000" placeholder="Jelaskan masalah secara jelas dan sopan..." required><?= old('isi') ?></textarea>
    </div>
    <div class="form-group">
        <label for="foto">Foto Bukti</label>
        <div class="upload-box">
            <input id="foto" name="foto" type="file" accept="image/jpeg,image/png">
            <strong>+ Pilih foto bukti</strong>
            <small>JPG/PNG, maksimal 3 MB. Contoh: foto kursi, meja, toilet, lampu, atau fasilitas rusak.</small>
        </div>
    </div>
    <label class="check-card">
    <input type="checkbox" name="anonim" value="1" <?= isset($_POST['anonim']) ? 'checked' : '' ?>>
    <span><strong>Kirim sebagai anonim</strong><small>Nama siswa tidak ditampilkan kepada publik/admin pada tampilan laporan. Sistem tetap menyimpan akun pengirim secara internal untuk kebutuhan riwayat.</small></span>
    </label>
    <div class="form-actions">
        <a href="dashboard.php" class="btn btn-secondary">Batal</a>
        <button type="submit" class="btn btn-primary">Kirim Pengaduan →</button>
    </div>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
