<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('siswa');

$pageTitle = 'Dashboard Siswa';
$userId = (int) $_SESSION['user_id'];

// jumlah pengaduan per status
$stmt = $pdo->prepare('SELECT status, COUNT(*) total FROM pengaduan WHERE created_by_user_id = :user_id GROUP BY status');
$stmt->execute(['user_id' => $userId]);
$counts = ['Baru' => 0, 'Diproses' => 0, 'Selesai' => 0];
$totalPengaduan = 0;
foreach ($stmt->fetchAll() as $row) {
    $totalPengaduan += (int) $row['total'];
    if (isset($counts[$row['status']])) {
        $counts[$row['status']] = (int) $row['total'];
    }
}

$stmt = $pdo->prepare('SELECT COUNT(*) FROM aspirasi WHERE created_by_user_id = :user_id');
$stmt->execute(['user_id' => $userId]);
$totalAspirasi = (int) $stmt->fetchColumn();

$stmt = $pdo->prepare('SELECT p.*, c.nama AS kategori FROM pengaduan p LEFT JOIN kategori c ON c.id = p.kategori_id WHERE p.created_by_user_id = :user_id ORDER BY p.created_at DESC LIMIT 5');
$stmt->execute(['user_id' => $userId]);
$pengaduanTerbaru = $stmt->fetchAll();

$stmt = $pdo->prepare('SELECT a.*, c.nama AS kategori FROM aspirasi a LEFT JOIN kategori c ON c.id = a.kategori_id WHERE a.created_by_user_id = :user_id ORDER BY a.created_at DESC LIMIT 5');
$stmt->execute(['user_id' => $userId]);
$aspirasiTerbaru = $stmt->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<section class="hero">
    <div>
        <span class="eyebrow">Portal Pengaduan &amp; Aspirasi Siswa</span>
        <h1>Suara kamu, perubahan untuk sekolah.</h1>
        <p>Halo, <?= e($_SESSION['name']) ?>. Laporkan masalah fasilitas sekolah atau sampaikan aspirasi dan idemu untuk kemajuan SMK Strada Jakarta. Bersama, kita bisa membuat sekolah menjadi lebih baik!</p>
        <div class="hero-actions">
            <a class="btn btn-primary btn-lg" href="buat_pengaduan.php"><?= icon('doc', 22) ?> Buat Pengaduan <?= icon('arrow', 20) ?></a>
            <a class="btn btn-lime btn-lg" href="buat_aspirasi.php"><?= icon('bulb', 22) ?> Kirim Aspirasi <?= icon('arrow', 20) ?></a>
        </div>
    </div>
    <div class="hero-art">
        <?= illustration_megaphone() ?>
        <div class="hero-note">Suara<br>Siswa<br>Untuk<br>Sekolah</div>
    </div>
</section>

<div class="stats-grid">
    <a class="stat-card" href="riwayat_pengaduan.php">
        <span class="stat-icon"><?= icon('doc', 28) ?></span>
        <small>Total Pengaduan</small><strong><?= $totalPengaduan ?></strong>
        <span class="stat-arrow"><?= icon('arrow', 18) ?></span>
    </a>
    <a class="stat-card" href="riwayat_pengaduan.php">
        <span class="stat-icon"><?= icon('bell', 28) ?></span>
        <small>Laporan Baru</small><strong><?= $counts['Baru'] ?></strong>
        <span class="stat-arrow"><?= icon('arrow', 18) ?></span>
    </a>
    <a class="stat-card" href="riwayat_pengaduan.php">
        <span class="stat-icon"><?= icon('gear', 28) ?></span>
        <small>Diproses</small><strong><?= $counts['Diproses'] ?></strong>
        <span class="stat-arrow"><?= icon('arrow', 18) ?></span>
    </a>
    <a class="stat-card" href="riwayat_pengaduan.php">
        <span class="stat-icon"><?= icon('check', 28) ?></span>
        <small>Selesai</small><strong><?= $counts['Selesai'] ?></strong>
        <span class="stat-arrow"><?= icon('arrow', 18) ?></span>
    </a>
    <a class="stat-card" href="riwayat_aspirasi.php">
        <span class="stat-icon"><?= icon('bulb', 28) ?></span>
        <small>Total Aspirasi</small><strong><?= $totalAspirasi ?></strong>
        <span class="stat-arrow"><?= icon('arrow', 18) ?></span>
    </a>
</div>

<div class="dash-grid">
    <div class="card table-card table-compact">
        <div class="card-header">
            <h3><?= icon('doc', 30) ?> Pengaduan Terbaru</h3>
            <a href="riwayat_pengaduan.php">Lihat Semua <?= icon('arrow', 18) ?></a>
        </div>
        <?php if (!$pengaduanTerbaru): ?>
            <div class="empty-state">Belum ada pengaduan. Yuk sampaikan laporan pertama kamu.</div>
        <?php else: ?>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>No</th><th>Judul Laporan</th><th>Tanggal</th><th>Status</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ($pengaduanTerbaru as $i => $item): ?>
                        <tr>
                            <td><?= str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) ?></td>
                            <td><?= e($item['judul']) ?></td>
                            <td><?= format_date($item['tanggal_pengaduan']) ?></td>
                            <td><span class="<?= status_class($item['status']) ?>"><?= e($item['status']) ?></span></td>
                            <td><a class="row-arrow" href="detail_pengaduan.php?id=<?= (int) $item['id'] ?>" aria-label="Lihat detail pengaduan"><?= icon('arrow', 20) ?></a></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <div class="cta-card">
        <span class="cta-icon"><?= icon('bulb', 26) ?></span>
        <h3>Punya ide untuk sekolah?</h3>
        <p>Sampaikan aspirasi, saran, atau ide kreatif kamu untuk membuat SMK Strada Jakarta menjadi lebih baik lagi.</p>
        <a class="btn btn-primary btn-lg" href="buat_aspirasi.php"><?= icon('pencil', 20) ?> Tulis Aspirasi <?= icon('arrow', 20) ?></a>
        <?= illustration_notepad() ?>
    </div>
</div>

<div class="card table-card table-compact">
    <div class="card-header">
        <h3><?= icon('bulb', 30) ?> Aspirasi Terbaru</h3>
        <a href="riwayat_aspirasi.php">Lihat Semua <?= icon('arrow', 18) ?></a>
    </div>
    <?php if (!$aspirasiTerbaru): ?>
        <div class="empty-state">Belum ada aspirasi yang dikirim.</div>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead><tr><th>No</th><th>Judul Aspirasi</th><th>Tanggal</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($aspirasiTerbaru as $i => $item): ?>
                    <tr>
                        <td><?= str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) ?></td>
                        <td><?= e($item['judul']) ?></td>
                        <td><?= format_date($item['tanggal_aspirasi']) ?></td>
                        <td><span class="<?= status_class($item['status']) ?>"><?= e($item['status']) ?></span></td>
                        <td><a class="row-arrow" href="detail_aspirasi.php?id=<?= (int) $item['id'] ?>" aria-label="Lihat detail aspirasi"><?= icon('arrow', 20) ?></a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
