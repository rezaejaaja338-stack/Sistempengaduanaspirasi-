<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('siswa');

$pageTitle = 'Riwayat Pengaduan';
$stmt = $pdo->prepare('SELECT p.*, c.nama AS kategori FROM pengaduan p LEFT JOIN kategori c ON c.id = p.kategori_id WHERE p.created_by_user_id = :user_id ORDER BY p.created_at DESC');
$stmt->execute(['user_id' => (int) $_SESSION['user_id']]);
$items = $stmt->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="page-intro split">
    <div><span class="eyebrow">RIWAYAT</span><h2>Pengaduan Saya</h2><p>Pantau seluruh laporan dan status tindak lanjut dari sekolah.</p></div>
    <a class="btn btn-primary" href="buat_pengaduan.php">+ Pengaduan Baru</a></div>
<div class="tabs"><a href="riwayat_pengaduan.php" class="active">Pengaduan</a><a href="riwayat_aspirasi.php">Aspirasi</a></div>
<div class="card table-card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Judul</th>
                    <th>Kategori</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                    <tr>
                        <td><strong><?= e($item['judul']) ?></strong><small class="table-sub">ID #<?= (int) $item['id'] ?> <?= $item['anonim'] ? '· Anonim' : '' ?></small></td>
                        <td><?= e($item['kategori'] ?? '-') ?></td>
                        <td><?= format_date($item['tanggal_pengaduan']) ?></td>
                        <td><span class="<?= status_class($item['status']) ?>"><?= e($item['status']) ?></span></td>
                        <td>
                            <a class="btn btn-small btn-secondary" href="detail_pengaduan.php?id=<?= (int) $item['id'] ?>">Detail</a></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$items): ?>
                    <tr>
                        <td colspan="5">
                            <div class="empty-state">Belum ada pengaduan.</div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
