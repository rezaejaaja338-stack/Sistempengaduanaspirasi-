<?php
require_once __DIR__ . '/../includes/functions.php';

// catat dulu role-nya biar baliknya ke login yg bener
$role = $_SESSION['role'] ?? 'siswa';

$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();
header('Location: ../' . $role . '/login.php');
exit;
