<?php
require_once __DIR__ . '/includes/functions.php';

if (is_logged_in()) {
    if ($_SESSION['role'] == 'admin') redirect('admin/dashboard.php');
    redirect('siswa/dashboard.php');
}

// halaman utama = login siswa, admin masuk lewat admin/login.php
redirect('siswa/login.php');
